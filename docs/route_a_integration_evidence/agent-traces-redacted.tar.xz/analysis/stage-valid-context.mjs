// Isolated test-context staging. Actual MCP only; no model/browser/Panel writes.
// Reads the public r74 task and completed session references, never assessor truth.
import assert from 'node:assert/strict';
import {createHash,randomBytes} from 'node:crypto';
import {appendFileSync,existsSync,mkdirSync,readFileSync,readdirSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {StdioImageClient} from '../dist/tools/image_panel.mjs';

const repo=fileURLToPath(new URL('../',import.meta.url));
const json=p=>JSON.parse(readFileSync(p,'utf8'));
const hash=p=>createHash('sha256').update(readFileSync(p)).digest('hex');
const safeId=v=>{assert.match(v,/^[a-f0-9]{32}$/);return v;};
const options=Object.fromEntries(process.argv.slice(2).reduce((out,value,index,all)=>{if(index%2===0){assert.ok(value.startsWith('--')&&all[index+1]);out.push([value.slice(2),all[index+1]]);}return out;},[]));
assert.ok(Object.keys(options).every(k=>['config','task','session','output'].includes(k)));
for(const key of ['config','task','session','output'])assert.ok(options[key]&&path.isAbsolute(options[key]),'Explicit absolute --'+key+' required');
const task=json(options.task),summaryPath=path.join(options.session,'summary.json');
assert.ok(existsSync(summaryPath),'Session is not complete; do not read or stage while it is running');
const summary=json(summaryPath);assert.equal(summary.exit_code,0);assert.equal(summary.timed_out,false);assert.deepEqual(summary.unfinished_mcp_events,[]);
assert.equal(task.task_id,'r74','This bounded staging script is only for the explicitly assigned r74 case');
assert.equal(task.declared_calibration,null,'This stage is pixel-domain only; do not reinterpret a new calibration task');
assert.equal(hash(task.source_path),task.source_sha256);
const eventsPath=path.join(options.session,'actual-tool-events.json'),events=json(eventsPath);
const reads=events.completed_mcp_calls.filter(c=>c.tool==='image_panel_current');assert.ok(reads.length,'Need an actual Panel read from completed Agent session');
const panelId=safeId(reads.at(-1).arguments.panel_id);
assert.equal(existsSync(options.output),false,'Retain original executions; use a new output directory');mkdirSync(options.output,{recursive:true});
const redact=v=>Array.isArray(v)?v.map(redact):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,/^(panel_url|token|evidence_token|owner_nonce|nonce)$/i.test(k)?'[REDACTED]':redact(x)])):typeof v==='string'?v.replace(/http:\/\/127\.0\.0\.1:\d+\/#[^\s"']+/g,'[REDACTED_PANEL_URL]'):v;
const save=(name,value)=>writeFileSync(path.join(options.output,name),JSON.stringify(redact(value),null,2)+'\n',{flag:'wx'});
const log=value=>appendFileSync(path.join(options.output,'calls.jsonl'),JSON.stringify(redact(value))+'\n');
const config=json(options.config),workspace=path.join(config.workspace_root,'images');
const walk=dir=>existsSync(dir)?readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):e.isFile()?[path.join(dir,e.name)]:[]):[];
const inventory=()=>Object.fromEntries(['objects','requests'].flatMap(n=>walk(path.join(workspace,n))).map(p=>[p,hash(p)]));
const originalConfig=process.env.MICROSCOPY_PLUGIN_CONFIG;process.env.MICROSCOPY_PLUGIN_CONFIG=options.config;
const client=new StdioImageClient({workspace,python:config.python,serverPath:path.join(repo,'dist/tools/plugin_server.mjs')});
const tag=randomBytes(6).toString('hex'),calls=[];let serial=0;
const call=async(name,args)=>{
 assert.ok(['image_panel_current','image_info','image_result','image_spatial_atlas','image_feature_field'].includes(name),'No other operation is authorized by this staging script');
 const parameters=['image_spatial_atlas','image_feature_field'].includes(name)?{...args,request_id:`stage-r74-${tag}-${++serial}`} :args;
 log({phase:'before_dispatch',actor:'test_operator_context_staging',tool:name,arguments:parameters});
 try{const r=await client.tool(name,parameters);log({phase:'completed',tool:name,data:r.data,image_block:!!r.png});calls.push({tool:name,request_id:parameters.request_id??null,object_id:r.data.object_id??null,image_block:!!r.png});return r.data;}
 catch(e){log({phase:'failed_or_unknown',tool:name,arguments:parameters,error:e.message,automatic_retry:false});throw e;}
};
const report={schema_version:1,actor:'test_operator_context_staging',purpose:'Provide actual saved existing-tool observations for a separate blinded Agent interpretation check; not Agent-selected ROI or hidden-truth certification',
 task_id:task.task_id,panel_id:panelId,workspace,source_sha256_before:hash(task.source_path),public_task_sha256:hash(options.task),completed_session_summary_sha256:hash(summaryPath),completed_session_events_sha256:hash(eventsPath),script_sha256:hash(fileURLToPath(import.meta.url)),calls,
 no_threshold_tuning:true,hidden_truth_read:false,model_invoked:false,browser_invoked:false,panel_presentation_modified:false,not_tested:['Agent interpretation of the staged evidence','browser gesture or visibility','statistical peak qualification','material identity']};
try{
 await client.rpc('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'route-a-stage-public-context',version:'1'}});
 const catalog=(await client.rpc('tools/list')).result.tools;
 const atlasTool=catalog.find(t=>t.name==='image_spatial_atlas'),featureTool=catalog.find(t=>t.name==='image_feature_field');assert.ok(atlasTool&&featureTool);save('actual-tool-schemas.json',{image_spatial_atlas:atlasTool,image_feature_field:featureTool});
 const enumValues=atlasTool.inputSchema.properties.peak_options.properties.refinement.enum;
 const refinement=enumValues.includes('quadratic_3x3')?'quadratic_3x3':enumValues.includes('quadratic')?'quadratic':null;
 assert.ok(refinement,'No explicitly supported quadratic refinement; stop rather than substitute an undocumented operation');
 report.refinement={requested:'quadratic_3x3',schema_values:enumValues,used:refinement,reason:'Use the current formally advertised parameter spelling; no scientific threshold adjustment'};
 const current=await call('image_panel_current',{panel_id:panelId});assert.equal(current.panel_id,panelId);const view=current.view;
 assert.equal(view.edit_state.dirty,false);assert.equal(view.edit_state.gesture_active,false);assert.equal(view.pending_result,null);
 const identity=view.frame_identity;assert.equal(identity.frame_index,task.frame_index);
 const source=await call('image_info',{object_id:safeId(identity.source_object_id)});
 assert.equal(source.source_identity.sha256,task.source_sha256);assert.equal(path.resolve(source.source_identity.path),path.resolve(task.source_path));
 const frame=await call('image_info',{object_id:safeId(identity.frame_object_id)});
 assert.equal(frame.frame_index,task.frame_index);assert.equal(frame.kind,'frame');assert.deepEqual(frame.shape_yx,[256,256]);
 // Current frame identity and source provenance are authoritative. No unseen
 // synthetic parameters, expected status or material truth enter this call.
 const before=inventory();save('provider-before-sha256.json',before);save('initial-current.json',current);
 const atlas=await call('image_spatial_atlas',{object_id:frame.object_id,rects:[[64,64,192,192]],window:'none',subtract_mean:true,max_peaks:16,max_size:256,peak_options:{threshold_rel:.1,refinement}});
 const field=await call('image_feature_field',{object_id:atlas.object_id,coordinate_domain:'pixel',display_feature:'family_count',max_size:256});
 assert.equal(atlas.kind,'spatial_atlas');assert.equal(field.kind,'feature_field');
 const newReferences=[atlas,field].map(o=>({provider:'image',object_id:o.object_id,request_id:o.request_id}));
 for(const record of [atlas,field]){
  const restored=await call('image_result',{request_id:record.request_id});assert.equal(restored.object_id,record.object_id);assert.deepEqual(restored.result_semantics,record.result_semantics);
  const read=await call('image_info',{object_id:record.object_id});assert.deepEqual(read.result_semantics,record.result_semantics);assert.deepEqual(read.samples??null,record.samples??null);
 }
 const afterCurrent=await call('image_panel_current',{panel_id:panelId});
 const sameState=afterCurrent.view.object.object_id===view.object.object_id&&afterCurrent.view.state_revision===view.state_revision&&afterCurrent.view.edit_state.draft_revision===view.edit_state.draft_revision&&afterCurrent.view.edit_state.dirty===view.edit_state.dirty&&afterCurrent.view.pending_result===view.pending_result;
 // A concurrent real edit is reported rather than overwritten or undone.
 report.panel_current_unchanged=sameState;
 report.initial_binding={object_id:view.object.object_id,frame_identity:identity,state_revision:view.state_revision,draft_revision:view.edit_state.draft_revision};
 report.final_binding={object_id:afterCurrent.view.object.object_id,state_revision:afterCurrent.view.state_revision,draft_revision:afterCurrent.view.edit_state.draft_revision};
 for(const [p,digest] of Object.entries(before))assert.equal(hash(p),digest,'Original provider file changed: '+p);
 report.original_provider_files_unchanged=Object.keys(before).length;
 report.source_sha256_after=hash(task.source_path);assert.equal(report.source_sha256_after,report.source_sha256_before);
 report.atlas={object_id:atlas.object_id,request_id:atlas.request_id,regions:atlas.regions,result_semantics:atlas.result_semantics};
 report.feature={object_id:field.object_id,request_id:field.request_id,samples:field.samples,result_semantics:field.result_semantics};
 report.actual_sample_statuses=field.samples.map(s=>s.status);report.new_references=newReferences;
 const after=inventory();save('provider-after-sha256.json',after);report.new_files_sha256=Object.fromEntries(Object.entries(after).filter(([p])=>!Object.hasOwn(before,p)));
 save('continuation.json',{schema_version:1,panel_id:panelId,operator_message:'Additional saved image observations were created with existing tools from an explicitly operator-selected source ROI. No Panel presentation or human edit was performed by this staging step. Read the referenced records, their saved parameters and current shared workspace yourself; explain which observations and judgments they support, which remain unknown, and whether any earlier interpretation should be revised. These are dependent computations of the same image, not a new experiment or an Agent discovery.',prior_references:newReferences});
 save('final-current.json',afterCurrent);report.execution='COMPLETED';save('report.json',report);
 console.log(JSON.stringify({execution:report.execution,actual_sample_statuses:report.actual_sample_statuses,new_references:newReferences,panel_current_unchanged:sameState,output:options.output},null,2));
}catch(e){report.execution='FAILED_OR_UNKNOWN';report.error=e.stack??e.message;save('failure.json',report);throw e;}
finally{await client.close();if(originalConfig===undefined)delete process.env.MICROSCOPY_PLUGIN_CONFIG;else process.env.MICROSCOPY_PLUGIN_CONFIG=originalConfig;}
