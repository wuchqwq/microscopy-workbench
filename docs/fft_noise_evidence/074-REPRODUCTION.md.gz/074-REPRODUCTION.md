# Cross-dataset false acceptance, before repair

Command (completed with exit code 0):

`python tests/fixtures/summarize_fft_noise.py --single analysis/controlled-backgrounds/raw-v3 --saved analysis/controlled-noise/public-full-primary --output analysis/controlled-backgrounds/aggregator-cross-dataset-original`

It printed `Aggregated and audited: {'single': 340}` and wrote `provenance.json` as if the unrelated saved result were bound. The holdout raw dataset and the main 510-image public dataset have different manifest/raw hashes. A copy of the original aggregator is retained in this directory. This output is evidence of a contract failure, not a valid joined analysis.
