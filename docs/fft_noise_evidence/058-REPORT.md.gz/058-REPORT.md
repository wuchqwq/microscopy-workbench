# Independent background holdout statistics

This is the preregistered holdout with new seeds 1000–1015; thresholds were not adjusted using it. The earlier 100–115 matrix was a preregistered development/regression set whose results had already been viewed. The holdout comprises 85 source images: five fixed signal/background models, each with one noise-free expected image and 16 seeded samples. The raw numerical harness evaluated each source under both windows and both refinement modes: **340/340 succeeded**. Independent reconstruction and auditing of integer-bin conjugate groups, one-to-one truth matches, and matched error calculations passed for all 340. The saved public primary Hann/mean/quadratic chain completed **85/85**, with **85/85** reported exact parity with raw numerical results and zero reported errors. The other three configurations are raw-harness results, not saved public statuses.

`provenance.json` records input, script, parameter, raw, and completed public hashes, the full matrix parameters, all 16 pair checks and the audit results. All 85 TIFF and associated float64 ideal NPY file/array hashes were independently checked. Per-condition counts, denominators, extra groups, matched errors and empirical percentiles are in `single-groups.csv`; the original raw JSONL retains each peak and each seed. The 1.5-bin truth gate and 3-bin peak separation are fixed conventions. Empirical p95 is a sample percentile, not a confidence interval or experimental error rate; matched-only errors exclude misses. These results quantify this finite synthetic model, not real-microscope accuracy.

## Confirmed implementation bug: DC scale

The previously established deterministic B+δ DC-scale defect and v3 repair are documented in the separate original raw analysis. This holdout uses weak periodic scenes rather than that analytic impulse and does not independently reconfirm or broaden that bug claim. All holdout evaluations used the fixed v3 revision; the numerical findings below are not additional confirmed implementation bugs.

## Quantified variation and bias

Under primary Hann/mean/quadratic, each scene matched its prescribed carrier in **16/16** noisy images; all 16 per scene also had unmatched candidate groups. Matched-only errors below use 16 matched components per row. For reference the one-wave noise-free baseline matched with no extra candidates. The affine noise-free case had 0.080% absolute period error and 0.057° direction error under quadratic refinement; integer-bin errors were 5.422% and 0.617°. Refinement bias and noise variability are distinct.

| Scene | Extra groups across 16 images | Absolute period error median / empirical p95 | Direction error median / empirical p95 |
| --- | ---: | ---: | ---: |
| signal Poisson | 112 | 0.251% / 0.642% | 0.189° / 0.255° |
| digital offset +100 | 112 | 0.251% / 0.642% | 0.189° / 0.255° |
| independent physical Poisson background, mean 100 | 113 | 0.302% / 0.701% | 0.140° / 0.283° |
| Gaussian read noise, σ=5 | 113 | 0.226% / 0.644% | 0.183° / 0.243° |
| known affine | 114 | 0.204% / 0.488% | 0.133° / 0.298° |

These descriptive summaries do not imply a universally ordered effect or statistical separation of the models. The comparison pairs share their signal-Poisson draw but physical background adds its own Poisson draw; the digital offset adds no randomness; read noise is an independent Gaussian draw. Every seeded digital-offset TIFF equalled its paired signal TIFF plus exactly 100 in float32 (16/16), and the corresponding raw peak rows were exactly equal for all 64 paired seed/configuration comparisons. For noise-free sources, float32 quantization occurs after adding the offset, so exact equality to `float32(signal)+100` is not assumed; the independently saved float64 expectation and actual TIFF hashes are retained.

## Method limitation and actual public status

The numerical peak criterion returned extra candidates for every noisy primary image, even when its true carrier was matched. This does not make those extra local maxima statistically significant or establish a physical lattice. In the completed **public** primary chain all five noise-free images had `insufficient_evidence`, while all 80 noisy images had `ambiguous`; the latter reached the 16-peak selection limit, making signature completeness unresolved. These are actual saved public statuses, not statuses manufactured from raw diagnostics. They are conditional on this single weak carrier, finite selection and this particular noise model; neither status is a probability, confidence level or material classification.

## Nonidentifiability

The observed periodic signal and its local candidates do not identify a material, unique lattice, or phase. The known affine transformation is a prescribed simulation input; a similar measured distortion alone cannot determine whether its origin was a scanner or the material. Neither physical-background counts nor digital offset can be inferred from an FFT peak list alone. No p-values, FDR, or significance calibration is claimed.
