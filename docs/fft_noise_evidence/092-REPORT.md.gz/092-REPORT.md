# Independent preprocessing truth — GPT-6.1 Sol

The four runnable unittests pass. They cover 28 saved public FFT configurations, seven source TIFFs, and 44 actual worker calls. No production code or existing fixture was edited. `CRITERIA.md` was written before either execution; tolerances were not changed after observing results. Both executions and all artifacts remain available (`run-1`, `run-2`, and their unittest logs).

Run from this checkout:

```sh
FFT_PREPROCESSING_ORACLE_OUTPUT=/absolute/fresh/output \
  PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m unittest discover \
  -s tests -p test_fft_preprocessing_oracle.py -v
```

The output directory must be fresh. Omitting the environment variable creates a retained temporary directory and prints its location. The test does not require the ignored analysis directory in a clean clone; external criteria-file hashes are recorded when that file is available.

## Actual producer and independent truth

The source under review is commit `d80a0f781c12ff6e0aa01469f311567372d67e56`, tree `624afd3fdd67b7db079e20c594969b03fbf236c3`. The owning implementation is `tools/image_workspace.py:1338–1367`: crop → float64 conversion → optionally subtract raw ROI mean → optionally multiply the y symmetric Hann then x symmetric Hann → NumPy fft2 → fftshift. The saved metadata explicitly states that order. There is no public window-then-mean option.

The actual installed NumPy2.5.4 `hanning` implementation and the [official definition](https://numpy.org/doc/stable/reference/generated/numpy.hanning.html) agree on the symmetric window

`h_m(t) = (1 − cos(2πt/(m−1)))/2`, `0≤t<m`.

This has m−1 in the denominator. It is not the periodic m-denominator Hann; even lengths do not attain1. Endpoint, symmetry, odd/even maxima, and numerical values are checked against an independent Decimal construction.

All reference arithmetic uses Decimal precision70 and independent Taylor roots of unity. The reference contains no FFT/IFFT, NumPy hanning, SciPy transform/window, or detector calls. The direct DFT is separable finite summation; fftshift is implemented as explicit modular output indices. A closed-form separable impulse reference is independently compared with that direct DFT. The only observed FFT input is captured by a test wrapper that forwards the unchanged input to the original NumPy fft2; it does not alter the producer source or manufacture reference outputs.

## Separate formulas for all four supported options

Let `x=B+Aδ_p`, N=HW, `e_p(k)=exp[−2πi(k_y p_y/H+k_x p_x/W)]`. B and A below refer to **actual stored input values**. Let `W(k)=H_H(k_y) H_W(k_x)` and `w_p=h_H(p_y)h_W(p_x)`, with `H_m(k)=Σ_t h_m(t) exp(−2πikt/m)`.

| Window | Raw mean subtraction | Exact DFT |
|---|---|---|
| none | false | `BN δ_(k=0) + A e_p(k)` |
| none | true | `A e_p(k) − A δ_(k=0)` |
| symmetric Hann | false | `B W(k) + A w_p e_p(k)` |
| symmetric Hann | true | `A w_p e_p(k) − (A/N) W(k)` |

Only the no-window rows have constant nonDC modulus |A|. The windowed rows generally have genuine nonDC variation from W(k), and mean-before-window generally leaves nonzero DC. In particular, removing the raw mean does not mean removing the mean of the windowed result.

For the original63² float32 B100/A1 impulse at(y20,x25), the independent windowed references give:

| Option | NonDC amplitude span |
|---|---:|
| none, either mean setting | exactly0 mathematically |
| Hann, meanfalse | 49195.67959853633 |
| Hann, meantrue | 0.10889247578371586 |

The rounded complex128 representation of the closed-form no-window reference may itself show a span~1.1e-16; the actual assertion uses Decimal modulus, not a false demand that every complex128 absolute-value calculation equal1 bit-for-bit.

## Proof of order dependence

Write P for multiplication by w, M for subtraction of the raw image mean. The production operator is PM:

`FFT(PM x)=FFT(xw) − mean(x) W(k)`.

The unsupported reverse order is MP:

`FFT(MP x)=FFT(xw) − N mean(xw) δ_(k=0)`.

For k≠0 the operators differ by `−mean(x) W(k)`, generally nonzero. The reverse operation zeros DC; the production operation generally does not. This is a deterministic mathematical distinction, not an uncertainty estimate.

The independent11×13 B100/A1 example gives maximum nonDC operator difference `1705.4529600719397`; production-order exact DC is `0.4008745315820911`, while reverse-order DC is a Decimal finite-reference residual about−2e-66. The reverse operator was calculated independently for the proof only; no unsupported worker request was sent.

## Actual input, roundoff, and fixed regression reserves

Cases cover11×13,12×14,13×16,17×19,63×63,13×17; prime/composite and rectangular odd/even axes; zero and nonzero backgrounds; an endpoint impulse; float32 and uint16 public TIFF inputs. For B1e8 float32, the requested+1 is quantized away: actual A=0. The no-window reference is a constant image's DFT, and Hann without mean subtraction still legitimately has a broad window transform. The test never calls this windowed transform flat.

Three distinct levels are retained: actual stored source, exact mean/Hann mathematical preprocessing of that source, and captured binary64 producer work. The maximum pointwise preprocessing discrepancy is checked separately. The exact direct DFT of captured work checks FFT arithmetic without blaming it for source quantization or preprocessing rounding. Comparing with ideal preprocessing permits the **measured** preprocessing L1 difference, because any DFT coefficient of a known input error is bounded by that L1 difference.

Prespecified numerical reserves are64u×max(1,maxabs_source) for pointwise preprocessing and512u×max(1,L1_actual_work) for the FFT comparison, u=2^-53. They are fixed regression criteria, **not certified PocketFFT bounds** or changes to production tolerances. The latter reserve is far below the large wrong-order effects above.

Selected maximum complex FFT errors against the exact DFT of actual work:

| Source | Max absolute complex error | Largest error / fixed reserve |
|---|---:|---:|
| B0 impulse11×13 | 2.48e-16 | .00391 |
| B100 impulse12×14 | 4.78e-13 | .00437 |
| B10000 edge impulse13×16 | 1.16e-10 | .00228 |
| uint16 B100 impulse17×19 | 1.33e-12 | .00602 |
| Original B100 impulse63² | 8.09e-12 | .00829 |
| Quantized constant B1e8,13×17 | 7.75e-7 | .000774 |
| Weak cosine source | 2.73e-12 | .00195 |

The large absolute number for B1e8 is scaled by the much larger transform energy; it is not proof of a resolved weak signal. Input and preprocessing errors remain separately recorded.

The32×35 float32 weak-cosine source uses background100 and amplitude.001 for each of two carriers. Its actual quantized image is independently transformed under all four supported settings. Under none+meantrue and Hann+meantrue, real saved public peaks recover exactly the four prescribed bins: [11,12], [12,24], [22,8], [23,20]. No assertion turns candidate recovery into statistical significance or physical identification.

## Evidence and limits

Final execution: `run-2/manifest.json`, `run-2/results.jsonl`, `run-2/calls.jsonl`, `run-2/filehash-manifest.json`, and `unittest-run-2.log`. Per-configuration directories retain captured work, independently computed exact-preprocessing and actual-work DFT arrays, and analytic impulse arrays. Scientific NPY arrays are separate from the provider's PNG previews. Each request/response, source TIFF, raw source-array bytes, processed-work bytes, saved FFT NPY, reference NPY, producer source and test source has a recorded hash. Both run manifests verify source TIFFs and producer source bytes unchanged.

Final test-source SHA256: `caf8e388fc09a8d7d5a61a5ba4520ab857d5957b7c2dbb24201318054b2364fc`.
Prewritten criteria SHA256: `64c4a81809dbca516b1bbd409db446a73350057f16d947d34e7b5109f6a2670e`.
Final run manifest SHA256: `cb668c0afa6fc635f73c867e841da57159b2d9d7877cd19581fbf7bc8000a5bf`.

These results establish the tested preprocessing mathematics and saved numerical agreement. They do not certify a universal FFT error bound, every individual candidate's resolution, image-noise significance, a physical lattice, a material identity, or general real-specimen accuracy. The separate peak-quality draft attachments were not used as established evidence.
