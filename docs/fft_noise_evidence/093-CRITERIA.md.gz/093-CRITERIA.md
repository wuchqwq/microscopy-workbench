# Independent preprocessing oracle — criteria fixed before execution

Reviewer: GPT-6.1 Sol. Scope: synthetic, saved public FFTs only. No production or existing fixture edits. No microscopy or physical interpretation follows.

Production contract under test: raw ROI → float64 → optional raw-ROI mean subtraction → optional separable symmetric Hann → unnormalised negative-exponent 2D DFT → fftshift. Symmetric Hann is h_m(t)=(1−cos(2πt/(m−1)))/2, not the periodic m-denominator window; an even length need not attain one. Official definition: https://numpy.org/doc/stable/reference/generated/numpy.hanning.html .

The independent reference uses stdlib Decimal precision 70, a fixed 70-digit π, sine/cosine Taylor series with 100 terms and range reduction, and direct separable DFT sums. It never calls FFT, IFFT, np.hanning, scipy window/FFT, or the production peak detector to manufacture truth. Source float32/uint16 values are converted exactly to Decimal. No longdouble accuracy assumption is made.

Analytic impulse reference for x=B+Aδ at p, M=HW, with raw-mean removal μ=B+A/M (or zero), and optional separable h_y h_x:
F=(B−μ) H_y(k_y)H_x(k_x)+A h_y(p_y)h_x(p_x) exp(−2πi(k_y p_y/H+k_x p_x/W)).
For no window, H_m(k)=m at k=0 and zero elsewhere. Thus nonDC modulus is |A| only in that no-window case. Mean-before-Hann gives A[h(p)e_p−H_y H_x/M], generally non-flat and generally nonzero DC. Window-then-mean gives B H_y H_x+A h(p)e_p minus a constant's DC term; it is a counterfactual, unsupported production option. These operators must differ in at least one nonDC coefficient in the chosen nonzero-background example.

Fixed B+Aδ cases, each with all four none/Hann × subtract_mean false/true settings:

| shape H×W | dtype | requested B,A | position y,x |
|---|---|---|---|
| 11×13 | float32 | 0,1 | 3,5 |
| 12×14 | float32 | 100,1 | 4,9 |
| 13×16 | float32 | 10000,1 | 0,0 |
| 17×19 | uint16 | 100,1 | 8,9 |
| 63×63 | float32 | 100,1 | 20,25 |
| 13×17 | float32 | 100000000,1 | 7,8 |

The last case must record actual A=0 after input quantization; it is not a failed mathematical impulse. Rectangles cover odd/even, prime/composite dimensions and an edge impulse.

Additional deterministic weak-cosine source: shape32×35, float32, B=100, amplitudes0.001 at q=(6/35,4/32) and q=(−5/35,8/32). Exercise all four preprocessing settings against the actual quantized source; only Hann+meantrue and none+meantrue are positive peak-recovery assertions. With refinement none, threshold_rel.05, max_peaks16, separation3, excludeDC3, require all four prescribed conjugate bins, without asserting that every returned candidate is physically real.

Criteria (fixed numerical test reserves, not certified PocketFFT bounds):

1. Capture the actual FFT input through an observational wrapper forwarding unchanged to the original NumPy fft2. Compare this work array pointwise to the independent Decimal raw-mean/symmetric-Hann reference; maximum error must be ≤64u·max(1,max|source|), u=2^-53.
2. Compare saved FFT to the independent direct DFT of captured actual work; maximum complex-bin error must be ≤512u·max(1,||actual_work||1). This is a prespecified regression tolerance, not a rigorous algorithm error guarantee.
3. Compare saved FFT to the independent exact-preprocessing reference and (for impulses) analytic separable closed form. Permit the directly measured preprocessing L1 difference plus the reserve in(2), and 1e-55·max(1,||source||1) for finite Decimal reference residual. The L1 propagation of a known input difference is mathematical; the FFT reserve is not certified.
4. Independent closed-form and direct reference results must agree within1e-55·max(1,||source||1). A wrong order, periodic-Hann substitution, wrong frequency sign, missing shift or wrong DC location must not be excused by assuming a flat windowed spectrum.
5. Verify source TIFF/hash and loaded source-array hashes, saved NPY hashes, metadata preprocessing order/window/removed_mean, dtype/shape, source unchanged at completion. Retain every call, error, test failure and report. No tolerance changes after looking at results; failures remain outcomes.

The standalone unittest writes to a fresh temporary directory by default, or the exact fresh directory named by FFT_PREPROCESSING_ORACLE_OUTPUT. The durable review execution will name a new directory below analysis/preprocessing-oracle/.
