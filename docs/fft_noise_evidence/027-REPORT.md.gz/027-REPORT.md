# Independent controlled-noise statistics — raw tier only

These are descriptive results from fixed synthetic inputs and four preregistered configurations. Both revisions produced 2,432 ROI records plus 196 adjacent comparisons, without reported execution errors. All 2,432 ROI records per revision passed an independent audit of exact integer-bin conjugate grouping, one-to-one maximum-cardinality/minimum-distance matching, unmatched sets, and matched period/direction errors. The saved dataset and raw inputs are identified by SHA-256 in `provenance.json`; the complete per-case/noise/dose/window/refinement/ROI aggregates and denominators are in `old-groups.csv` and `new-groups.csv`. For one-truth scenes, `one` is a single match; `both_or_all` is reserved for scenes with at least two truths. The empirical p95 is the 95th percentile of observed **absolute matched errors**, not a confidence interval, an experiment error rate, or a measure of undetected signals. Results use the 1.5-bin truth matching convention and fixed 3-bin peak separation.

This report does not include the public saved-chain tier: the independent aggregation was run before confirmation of its completion. The raw diagnostic family and comparison values are not saved public feature statuses. The script accepts only a completed `--saved` result and writes it to a new output directory; never read a partial run as a final distribution.

## Confirmed implementation bug: DC scale

The fixed analytic B=100 + unit impulse has flat non-DC modulus when window=none and mean subtraction=false. Under these two refinement settings v2 returned 16 raw peaks (12 exact conjugate groups); v3 returned zero. The peak rows changed only in these two delta-control configurations across all 2,432 ROI comparisons. The Hann delta control is different: windowing the background produces actual non-flat spectral content, and eight candidate groups remained under both revisions and both refinements. This comparison supports the narrow DC-scale numerical defect and fix; it does not establish a statistical detector or physical interpretation.

## Quantified variation and measurement bias

For the noise-free off-bin single carrier, integer-bin peak location gave a signed period error of +4.834% and direction error 0.399° with either window. Quadratic refinement gave −0.209% and 0.031° under Hann, but +2.344% and 0.308° under no window. This fixed, noiseless example demonstrates estimator/window bias, not a guarantee of improved accuracy for all signals.

For the same off-bin carrier under Hann, Poisson D=500 and quadratic refinement, all 16/16 samples matched; among these 16 matches the median absolute period error was 0.209% and empirical p95 0.255%, while median direction error was 0.039° and empirical p95 0.055°. The integer-bin period error was 4.834% for all 16 matches. These summaries exclude misses by construction; raw per-seed details remain in the source JSONL. The seed samples are descriptive of this finite simulation, and trends need not be monotone for individual seeds.

For the weak true carrier at the same dose and Hann setting, 16/16 images matched the true component, yet 16/16 also had extra unmatched groups (114 total across 16 images). Uniform Poisson noise had at least one candidate group in all 16 images (128 groups total). These numbers are not false-discovery rates: the numerical peak rule does not provide a significance test and noise is expected to contain local maxima.

## Method limitations and ambiguity

With Hann and D=500, all 16 near-doublet images matched exactly one of the two prescribed truths, whereas all 16 four-bin-separated controls matched both. The same pattern appeared in the two respective noiseless baselines. These are outcomes of this discrete detector, peak-separation setting and matching convention; they do not establish a Rayleigh criterion or physical resolving power.

For the sloped-background case, Hann D=500 matched the carrier in 16/16 images with no unmatched groups, while the no-window setting matched it in 16/16 but had extra groups in 3/16 images. This one background example does not guarantee behavior for other backgrounds. In the mixture case, the two prescribed components were matched in all 16 Hann D=500 samples. Each adjacent half ROI likewise matched both local components in all 16 samples; their raw finite-angle comparisons were `incompatible` in 16/16 for the Hann, integer-bin, D=500 configuration. The mixed full ROI is deliberately not scored as local recovery. These are geometry diagnostics, not public saved statuses or proof of separate material domains. A public feature `valid` status, when available, means usable numerical observations under that API's criteria; it does not establish a unique lattice, physical phase or statistical significance.

## Nonidentifiability

The two detected periodic components can arise from a single lattice or a superposition; these observations alone cannot select between those explanations. Similarly, the prescribed affine warp may represent scanner distortion or a real change in the specimen; the FFT output alone cannot determine its origin. No real-specimen measurement uncertainty, physical lattice, p-value or FDR is established here.
