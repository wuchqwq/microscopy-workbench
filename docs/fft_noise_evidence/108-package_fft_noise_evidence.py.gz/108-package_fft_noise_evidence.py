from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
root=Path.cwd(); out=root/'docs/fft_noise_evidence';out.mkdir(exist_ok=False)
files=[]
def add(p):
 p=root/p if not isinstance(p,Path) else p
 if not p.is_file(): raise FileNotFoundError(p)
 if p not in files: files.append(p)
def tree(p):
 for f in sorted((root/p).rglob('*')):
  if f.is_file() and f.suffix in ('.json','.jsonl','.csv','.md','.log','.txt','.py'):add(f)
for d in ('raw-v2','raw-v3'):
 for f in ('raw.jsonl','run.json','summary.csv'):add(Path('analysis/controlled-noise')/d/f)
for d in ('public-subset-r2','public-full-primary'):
 for f in ('calls.jsonl','results.jsonl','summary.json','summary.csv','filehash-manifest.json'):add(Path('analysis/controlled-noise')/d/f)
for f in ('manifest.json',):add(Path('analysis/controlled-noise/dataset')/f)
for d in ('public-subset','final-statistics','independent-statistics','independent-statistics-draft-1'):
 tree('analysis/controlled-noise/'+d)
for f in (root/'analysis/controlled-noise').glob('*.log'):add(f)
for f in (root/'analysis/controlled-noise').glob('*.py*'):add(f)
for f in ('run.json','summary.csv'):add(Path('analysis/controlled-noise/ci-raw')/f)
for d in ('statistics','audit-final','audit-final-draft','aggregator-cross-dataset-original'):
 if (root/'analysis/controlled-backgrounds'/d).exists():tree('analysis/controlled-backgrounds/'+d)
for f in ('manifest.json','parameters.json'):add(Path('analysis/controlled-backgrounds/dataset')/f)
for f in ('raw.jsonl','run.json','summary.csv'):add(Path('analysis/controlled-backgrounds/raw-v3')/f)
for f in ('calls.jsonl','results.jsonl','summary.json','summary.csv','filehash-manifest.json'):add(Path('analysis/controlled-backgrounds/public')/f)
for f in (root/'analysis/controlled-backgrounds').glob('*.log'):add(f)
for f in ('REPORT.md','CRITERIA.md','unittest-run-1.log','unittest-run-2.log'):
 add(Path('analysis/preprocessing-oracle')/f)
for d in ('run-1','run-2','root-verification'):
 for f in ('manifest.json','results.jsonl','calls.jsonl','filehash-manifest.json'):add(Path('analysis/preprocessing-oracle')/d/f)
add(Path('analysis/package_fft_noise_evidence.py'))
index=[]
for i,p in enumerate(files):
 # Resolve relative additions inside this task's root only.
 if not p.is_absolute():p=root/p
 rel=p.relative_to(root).as_posix();dest=out/(str(i).zfill(3)+'-'+p.name+'.gz')
 h=hashlib.sha256()
 with p.open('rb') as src,dest.open('wb') as dst,gzip.GzipFile(fileobj=dst,mode='wb',filename='',mtime=0) as gz:
  for chunk in iter(lambda:src.read(1024*1024),b''):h.update(chunk);gz.write(chunk)
 index.append({'source':rel,'archive':dest.name,'source_bytes':p.stat().st_size,'source_sha256':h.hexdigest(),'archive_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
(out/'index.json').write_text(json.dumps({'format':'Each gzip file decompresses to the exact original bytes; no reserialization.','files':index},indent=2)+'\n')
for name,src in [('main-groups.csv','analysis/controlled-backgrounds/audit-final/main/new-groups.csv'),('holdout-groups.csv','analysis/controlled-backgrounds/audit-final/holdout/single-groups.csv')]:shutil.copy2(root/src,out/name)
source_paths=[p for p in (root/'tests').rglob('*') if p.is_file() and (p.name.startswith(('controlled_fft','evaluate_fft','summarize_fft','test_fft','test_controlled')))]
(out/'tested-source-sha256.json').write_text(json.dumps({str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths},indent=2)+'\n')
print('Packaged files',len(index),'compressed bytes',sum(p.stat().st_size for p in out.iterdir()))
