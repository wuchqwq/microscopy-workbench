import {createImagePanel} from '../../dist/tools/image_panel.mjs';
import {prepareOwnedPanelRegistration} from '../../dist/lib/panel_ownership.mjs';
import {resultSemanticsModel} from '../../dist/ui/image-panel/result-semantics.mjs';
import {mkdtempSync, writeFileSync} from 'node:fs';
import path from 'node:path';
const A='a'.repeat(32),B='b'.repeat(32),C='c'.repeat(32),D='d'.repeat(32);
const semantics={version:1,scope:'candidate_measurement_and_assisted_interpretation',numerical:{execution:'completed',scope:'saved joint_observations result',checks:[]},measurement_reliability:{scope:'saved joint_observations result',assessments:[{aspect:'noise_significance',scope:'saved joint_observations result',status:'not_assessed',basis:'No qualified noise significance assessment is recorded.',source_fields:[]}]},interpretation:{scope:'conditional candidate interpretation',assessments:[]}};
async function run(label,records,start){
 const workspace=mkdtempSync(path.resolve('analysis/astra-route-a-review/'+label+'-'));
 const client={async rpc(method){return {result:method==='tools/list'?{tools:[{name:'image_info',inputSchema:{}}]}:{}}},async tool(name,args){if(name!=='image_info')throw Error(name);return structuredClone(records[args.object_id]);},async close(){}};
 const owned=prepareOwnedPanelRegistration({workspace,panel_id:D});let panel;
 try{panel=await createImagePanel({workspace,python:process.execPath,object_id:start,client,panel_id:D,helper_session_id:owned.helper_session_id,panel_generation:owned.generation,journalDirectory:owned.journalDirectory});owned.publish(panel);const state=await (await fetch(panel.url.split('/#')[0]+'/api/state',{headers:{'X-Panel-Token':panel.token}})).json();writeFileSync(path.join(workspace,'http-state.json'),JSON.stringify(state,null,2));return {label,input_has_semantics:!!records[start].data.result_semantics,visible_kind:state.object.kind,visible_model:resultSemanticsModel(state.object),sequence_has_semantics:!!state.sequence_evidence?.result_semantics,sequence_has_projection:!!state.sequence_evidence?.result_semantics_projection};}finally{if(panel)await owned.close(panel);}
}
const view={data:{object_id:B,kind:'view',display:{},annotations:[],panels:[]},png:'iVBORw0KGgo='};
const rows=[{frame_index:0,view_object_id:B,selected_object_id:B,status:'VERIFIED'}];
const joint={data:{object_id:A,kind:'joint_observations',request_id:'repro-joint',sequence_object_id:D,correspondence_object_id:C,reference_index:0,frame_observations:rows,observations:[],result_semantics:semantics}};
const results=[];
results.push(await run('joint',{[A]:joint,[B]:view,[C]:{data:{object_id:C,kind:'region_correspondence',sequence_object_id:D,rows}}},A));
results.push(await run('legacy-peaks',{[A]:{data:{object_id:A,kind:'fft_view',peak_detection:{version:3},display:{},panels:[],annotations:[]},png:'iVBORw0KGgo='}},A));
writeFileSync('analysis/astra-route-a-review/results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));
