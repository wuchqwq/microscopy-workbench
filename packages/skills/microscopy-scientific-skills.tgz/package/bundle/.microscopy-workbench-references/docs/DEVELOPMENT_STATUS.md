# Development status

[English](DEVELOPMENT_STATUS.md) · [简体中文](DEVELOPMENT_STATUS.zh-CN.md) · [Project overview](../README.md)

## Current verified mainline: 2026-11-05

This is the current implementation index. It was checked through the GitHub connector against main [c69424ac25a35efd816d68cacd5904f5381c7485](https://github.com/wuchqwq/microscopy-workbench/commit/c69424ac25a35efd816d68cacd5904f5381c7485), merged on 2026-11-04.

[PR #131](https://github.com/wuchqwq/microscopy-workbench/pull/131) preserves the reviewed workbench stack through #130 and its dependency history. Its merge message explicitly excludes independent [PR #105](https://github.com/wuchqwq/microscopy-workbench/pull/105) and the separate STEM candidate. No GitHub Release was published at this check. Source admission does not create new numerical, Agent, native-platform or real-specimen acceptance evidence.

### Implemented in this mainline

- The DM-free MCP scientific provider, optional Skills, local Image Panel and structured CLI share provider objects and original request journals.
- Direct image-first ROI → FFT, multiple ROI editing, source/FFT comparison, explicit point/line measurements and conditional peak remeasurement. Basic FFT does not require an observation reason or an explicit workspace save.
- Whole-analysis explicit savepoints, separate working edits and execution history, guarded normal reopen, crash-draft choices and original-request recovery.
- Headless saved-ROI comparisons with independently checked source/FFT association, source-bound reports, execution-history reads and explicit missing-computation options.
- Persistent source-proof create/info/revoke and guarded adoption. Retrospective proof retains original qualification and cannot turn a formerly unavailable FFT input into strict pre-execution reuse.
- Bounded ROI/atlas/multiscale observations and active follow-up; conditional single-domain GPA, projected winding, finite general/twin structure comparisons and the first cross-method continuation tools.
- A Windows Electron development entry reusing the Panel/provider, with native menus and Save / Don't Save / Cancel.

See the [workflow](WORKBENCH_WORKFLOW.md), [workspace contract](ANALYSIS_WORKSPACE.md), [CLI](CLI.md), [desktop entry](DESKTOP.md) and [runtime support](CI_SUPPORT.md). Tool presence is not proof that optional dependencies or a scientific input satisfy a tool's qualification gates.

### What the existing evidence actually covers

| Evidence | Recorded scope | Limits |
| --- | --- | --- |
| [Single-image closeout](validation/single-image-closeout-20261104.md) | Public synthetic Windows desktop mouse/keyboard ROI edits, two FFTs, source comparison, peak revision, save/cancel/Don't Save/normal reopen; separate read-only source/savepoint audit | Not peak-localization accuracy, strain, real-specimen physics, clean-machine installation or full GUI usability. Exact 760×800 and narrow-window scientific editing remain untested. |
| [Persistent source-proof acceptance](validation/persistent-source-proof-b-20261104.md) | Formal stdio MCP over existing public long histories, CLI/Panel consumers, original-qualification preservation, revocation/adoption and no new FFT during proof checks | Proof-entry native mouse flow remained NOT_TESTED after a tool safety stop. Hashes are consistency records, not signatures or independent specimen observations. |
| [Registered Panel recovery](INSPECTOR_PANEL_RECOVERY.md) | Owned registered-helper and Inspector recovery contracts, exact checkpoint/generation and explicit evidence revalidation | Legacy unregistered archives and unsupported states are separate. A restored card can be unvalidated; no blanket cold-recovery qualification follows. |
| Method-specific acceptance reports | Their exact numerical, protocol, model and synthetic-input scopes | Historical failures and NOT_TESTED/HOLD scopes remain in force where not superseded by specific later evidence. No universal speedup or real-material identification follows. |

The closeout reports name their tested source commits and then-current branch states. Their original “unmerged” wording is historical, even when that source is now in main. They have not been rewritten or rerun for this documentation update. Candidate CI reported in a merge record is not a newly executed check on this documentation patch or a substitute for exact-head release checks.

### Remaining boundaries

- Automatic image-feature proposals remain **EXPERIMENTAL**, including recorded missed positives. Empty proposals do not prove a normal or uniform specimen.
- Structure/reflection compatibility does not establish a chemical phase, 3D twin, material dislocation or coherent atomic boundary.
- GPA requires explicit source-domain/reference assumptions; topology remains conditional projected evidence. No ptychographic reconstruction or live instrument control is included.
- Actual human usability, current native macOS/Linux desktop qualification, real-specimen physical accuracy, clean-machine installation/distribution and upgrade recovery remain separate scopes.
- Narrow-window/DPI behavior, original unresolved failure sites and long-history proof-reading cost retain their report-specific open limits. Later successful isolated tests do not erase an earlier failure or qualify an unvisited state.
- Independent STEM analysis, new physical-forward/blind-test candidates and open PR results must be verified and admitted separately before being described as current mainline functionality.

For current releases or another checkout, refresh its exact ref and relevant CI/acceptance records. Do not restore an old branch status from the archive below as the current truth.

## Historical implementation archive

The following is the earlier 2026-11-01 implementation index, preserved for source ancestry and review context. Its branch labels, “current”, “open”, “unmerged” and qualification statements apply to that historical snapshot, not to the verified mainline summary above.

### Current merged main — 2026-11-01 snapshot

- Main after authorized merge-commit sequence: `14613c4f5fba5af941568d5c71413928c627bd9d` (PR #48 `cc41d46` followed by #49 `14613c4`). Its Git tree equals the integrated #49 head tree; refresh the live main before release or Mac migration.
- #44/#46/#47 implementation ancestry is already contained in #48. #46's obsolete stacked PR was closed administratively as superseded; it was **not** merged separately and must not be merged again. #45 private specimen intake remains independent and unmerged.
- The reviewed #49 PR-head 14 CI checks and public synthetic GUI/Agent tests are recorded; they are **not** automated results on the final GitHub main merge SHA. At audit time main had no push/check-run record. See [pre-Mac exact-HEAD gate and reproducible checklist](PRE_MAC_BASELINE_GATE.md).
- The [GUI integration closeout](GUI_FIRST_INTEGRATION_CLOSEOUT.md) reports **PASS** for a separate public API helper normal cold close/reopen, preserved source/science hashes and read-only `restored_unvalidated` display. Formal **registered-MCP Panel** restart and same-window qualified reattachment remain **HOLD**; human usability, current-main macOS GUI and real-material physical interpretation remain separately untested/held.
- No tag or complete desktop/physical-science release qualification follows from merging these PRs. Automatic F4b proposals retain original missed positives and EXPERIMENTAL status.

**Historical note:** The implementation/branch descriptions below preserve the conditions at their original review dates. Statements such as “open”, “unmerged” and “GUI gestures NOT_TESTED” apply to those earlier snapshots, **not** to the current main status above. Do not rewrite old acceptance ledgers.

### Manual regions / crystal integration candidate (historical review snapshot)

The dependent [GUI-first round 1](GUI_FIRST_ROUND1_ACCEPTANCE.md) adds visible
ROI observations, explicit continuation, finite provider-qualified evidence,
and persistent revision requirements. It retains the parent scientific records
and limits. Its browser/model/numerical scopes are recorded separately.
The [integration closeout](GUI_FIRST_INTEGRATION_CLOSEOUT.md) freezes that GUI
scope, rehearses dependency merges locally and records cold-helper re-admission
as a separate qualification gate. No further GUI features are added there.

`integration/manual-crystal-evidence` composes open #44/#46/#47 without merging
main. A bounded read-only Panel handoff preserves fractional anchors and exposes
the existing canonical processing edges/exact source/calibration references.
Actual browser ROI/peak gestures, real FCC MCP/simulation, unchanged-spectrum
revision and separate fresh-model recovery are recorded in
[integration acceptance](MANUAL_CRYSTAL_ACCEPTANCE.md). The historical reports
below retain their original NOT_TESTED/failure scopes. Private-sequence data
handoff passed locally; independent physical interpretation under #43 stays HOLD.
See [workflow / remaining calibration-continuation boundary](MANUAL_CRYSTAL_WORKFLOW.md).

### F4b manual image-first freeze (dependent review branch)

`feature/image-first-discovery` starts from #44 at `9ca6b44`; #44 remains
independent and unmerged unless its live PR says otherwise. The supported first
version records a researcher's explicit ROI/reason, calls existing scientific
tools, binds/reviews exact-source evidence, then saves, revises and recovers it.
Manual support is limited to the public synthetic software/numerical scope;
real specimens and GUI gestures remain NOT_TESTED. Automatic spatial-feature
proposal is **EXPERIMENTAL**, not qualified reliable anomaly detection. A full
structure field is not required. Qualified GPA can hand off to the existing
method-plan mechanism; no new global planner/request authority is introduced.
See [method and limits](IMAGE_FIRST_DISCOVERY.md), [current freeze acceptance](F4B_FREEZE.md)
and [historical implementation acceptance](F4B_ACCEPTANCE.md).
Registered64px proposals missed the two positive comparison cases; this known
failure remains explicit alongside successful source/revision/recovery software
checks. The post-hoc32px diagnostic is not independent blind success. Empty
proposals do not establish normality. No physical defect, twin or phase is
confirmed by appearance. Real experimental validation remains tracked by
[Issue #43](https://github.com/wuchqwq/microscopy-workbench/issues/43), separately
from this limited software freeze.

### F4-full first cross-method slice (review branch)

`feature/f4-cross-method-loop` starts at reviewed main `9fbc769` (F3b #42,
including its finite-direction correction). It adds three optional formal image
tools for saved fixed_g GPA → sourced phase follow-up → conditional topology,
or missing-information/stop decisions. The original request journals own all
attempt slots/reservations, failures, unknown outcomes and recovery. No scientific
kernel, global scheduler, source FFT or new model service is introduced.

[Method/API](CROSS_METHOD_ANALYSIS.md) and [acceptance](F4_CROSS_METHOD_ACCEPTANCE.md)
record actual four-case MCP results and same-cap fixed-sequence comparison,
including the slower positive active path. The first two new-model attempts
encountered client approval blocks and remain recorded. The authorized isolated
test configuration now supports actual fresh-model decisions and original-ID
recovery, with global configuration unchanged. See the separate
[authorization/performance closeout](F4_CROSS_METHOD_CLOSEOUT.md).
GUI/real specimen work is separate; no feature PR was merged.

### General crystallographic evidence review increment

An independent branch from main `9fbc769` adds
[`structure_general_compare`](GENERAL_CRYSTALLOGRAPHIC_EVIDENCE.md): two adjacent
saved ROI observations, explicit possibly different structures/orientations,
unchanged ASE/diffsims and reflection comparison, with separate model
qualifications and conditional evidence. It does not inherit unmerged
#44/#45/#46, alter F3b Sigma3 semantics, identify phases or name generic relations
twins. [Executed acceptance](GENERAL_CRYSTALLOGRAPHIC_ACCEPTANCE.md) distinguishes
analytic checks, actual simulations/MCP, preserved history and NOT_TESTED scopes.

### Reviewed implementation ancestry

| Scope | Source PR | Exact reviewed source commit |
| --- | --- | --- |
| F1a bounded multiscale fields/domains | #28 | `44495088968132b7286856097027f2233f73976c` |
| F4-lite incremental active analysis | #31 | `66139080de49e79158da242f51537dcd87258916` |
| Main/README/documentation CI integration | #32 | `f1ffbe82523e9d890974ce6e2354a7b4eb1f7136` |
| F4 adjacency/evidence/integrity closeout | #35 | `3678c54a0b8c57ec027fcfd03fd856489d26184c` |
| F2a classical GPA | #36 | `fc3a207fceeeab9f0285ab02596859d90b84d80c` |
| Independent F4/GPA integration | #37 | `ea09c091af503b342bba86cb86a427da9c0efed5` |
| F3a projected topology, v2 group correction | #38 | `8a3a05321afceed25a076c12edfa2edb7a4dac70` |

The final F3a branch contains the reviewed integrated histories, including #36
through #37. Consolidation retains those commit identities rather than replaying
GPA twice, squashing away ancestry, or separately landing an older conflicting
F1a tree. The previous main is `562416cb56fb76034ebc219101ea86845ed5cea4`.
Original source branches and the R3 frozen baseline are retained.

The closeout changes synchronize the two README languages, expose optional GPA
installation and current method links, and preserve explicit outstanding scopes.
Scientific kernels, thresholds, historical arrays, journals and acceptance ledgers
are not rewritten for this landing. The landing PR must run the complete existing
CI on its own candidate and be merged with its checked head SHA.

### Scientific capability and limits

F1a/F4-lite provide bounded local structure evidence and incremental follow-up;
F2a provides conditional single-domain phase/displacement/finite-tensor fields;
F3a provides conditional projected winding/closure evidence from saved bands.
These modules are composable, not a mandatory analysis pipeline.

F3a v2 groups circuits by strict geometric nesting before checking phase validity.
Several groups have separate fits and no shared top-level Burgers vector. Geometric
groups are not identified defect cores. Historical v1 objects retain their original
reports, including the known mixed-loop limitation; use an explicit new request
and previous-result link to make a v2 revision.

Use [F4 closeout](F4_LITE_CLOSEOUT_ACCEPTANCE.md),
[F2a acceptance](F2A_ACCEPTANCE.md), [F4/GPA integration](F4_F2A_INTEGRATION.md)
and [F3a acceptance](F3A_ACCEPTANCE.md) for numerical and protocol evidence.
Green CI means the declared automated checks passed; it is not experimental
accuracy, independent physical confirmation or a claim of universal speedup.

### Deferred qualification, not hidden completion

- Actual Panel mouse/keyboard gestures, saved peak movement and refresh remain
  NOT_TESTED where recorded. A human-led prepare/resume session can qualify them;
  scripted MCP revision and returned PNGs are different scopes. Preserve the
  prior browser safety stop; do not bypass it.
- Fresh-model comprehension of combined GPA/topology Skills, native plugin
  auto-discovery, real specimens and the unqualified platform/instrument scopes
  retain their recorded NOT_TESTED states.
- Feature-specific cancellation/lost-response/interrupted-worker injection remains
  separate from successful original-request and new-client recovery.

These are follow-up qualification tasks, not prerequisites for F3b algorithm
work. No release tag or broader validation claim follows from merging the stack.

### F3b first increment (review branch, Issue #41)

The new `feature/f3b-twin-interface` branch starts at consolidated main
`f0acf9e`, with no old-stack merges. It adds source-bound Sigma3 {111}
candidate orientations and projected reflection/interface comparisons for
ideal conventional monospecies FCC4/diamond8 references. It reuses actual
saved diffsims simulations and current F1/F4 observations, with an untwinned
control and no independent target-domain refit. Full unmatched evidence has
a bounded read-only MCP endpoint. See [method and API](PROJECTED_TWIN_EVIDENCE.md)
and [qualification scope](F3B_ACCEPTANCE.md). This is conditional evidence,
not automatic twin identification; GUI gestures remain a separate deferred task.

The original admission guidance for this increment remains:

Start a new branch from the consolidated main, not from an old stacked feature
branch. Read AGENTS.md and roadmap #16. Reuse saved domain/FFT observations and
existing crystallographic tools to test explicitly sourced candidate twin
operations and projected interface relations. Separate compatibility,
incompatibility and insufficient evidence; do not upgrade a 2D angle or mirrored
appearance into a unique 3D twin identification.

Choose a small supported crystallographic scope and independent positive,
ordinary-nontwin and projection-ambiguous controls. Keep source/calibration
identity, reproducible revisions, export/recovery and old-object compatibility.
The developer chooses the algorithm and PR split. Do not expand this increment
into automatic phase identification, all twin systems, F4-full, model training
or a new framework. New feature PRs remain subject to review and separate merge
authorization.
