# Public F4b evidence

The historical implementation records through `6dede0a` below are retained, not
relabeled final-HEAD tests. Manual image-first has limited synthetic
software/numerical qualification; automatic proposals are **EXPERIMENTAL**.
See the [current freeze report](../../F4B_FREEZE.md) for final-HEAD acceptance.

New freeze evidence, kept separately from the original records:

- [Actual explicit manual ROI MCP/Python chain and fresh-client recovery] (not bundled; see source checkout: manual-freeze.json)
- [Original accepted cross-ROI history fault before the recovery fix] (not bundled; see source checkout: freeze-history-counterexample.json)
- [Current-code read-only recovery of historical no-label objects] (not bundled; see source checkout: freeze-legacy-readonly.json)
- [Byte-for-byte preservation of scientific code and original public evidence] (not bundled; see source checkout: freeze-preservation.json)

Historical evidence:

- [Frozen comparison plan](../../F4B_BENCHMARK_PREREGISTRATION.md)
- [Primary summary, original report hashes and retained failures] (not bundled; see source checkout: primary-summary.json)
- [Exact twelve-row entrance comparison CSV] (not bundled; see source checkout: primary-comparison.csv)
- [Separate post-hoc scale diagnostic] (not bundled; see source checkout: scale-diagnostic.json)
- [Actual fresh-model decisions, image delivery and new-session recovery] (not bundled; see source checkout: fresh-agent.json)
- [Final compiled original-record read-only supplement] (not bundled; see source checkout: final-readonly.json)
- [Historical scope and reproduction](../../F4B_ACCEPTANCE.md)

Primary64px image scanning missed both positive inputs. The field also missed
same-carrier contrast depression; manual attention proceeds without requiring
that field. The positive new-model example below is a different192px input and
proves tool composition, not a replacement benchmark win or a material defect.

Actual MCP source/ROI feedback from the independent new Agent:

![Source-bound image-first candidates on a public analytic image] (not bundled; see source checkout: fresh-agent-candidates.png)

Explicit synthetic manual attention and its existing numerical evidence:

![Manual attention on the original public image] (not bundled; see source checkout: manual-attention.png)
![Original attention with saved FFT/peak/measurement evidence] (not bundled; see source checkout: manual-evidence.png)

All images are display feedback. Actual numerical arrays remain in the
scientific workspace/export with their own dtype, calibration and hashes. No
private specimen, browser screenshot or unique phase/twin/dislocation claim is
represented here.
