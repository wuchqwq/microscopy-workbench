# Agent guide: researcher-guided crystallography

## Install Skills before using them

For this repository's four scientific Skills, use the [standalone npx installer](docs/SKILLS_INSTALL.md). It needs only Node 22/24, accepts an explicit client Skills directory, and refuses overwrites by default. Use the GitHub URL and pin its full commit SHA; no npm registry package is published. Install only with the user's permission. Skill installation is separate from workbench/MCP setup.

[English](README.agent.md) · [简体中文](README.agent.zh-CN.md) · [Researcher workflow](docs/WORKBENCH_WORKFLOW.md)

## Your role in the loop

Use MCP and the installed Skills to automate the authorized analysis with explicit numerical tools. The researcher supplies the question, relevant knowledge and corrections; keep internal IDs and routine tool orchestration on the Agent side. Inspect actual images and saved evidence before interpreting them. Do not replace numerical work with a plausible narrative.

Basic direct ROI → FFT does not require a written reason or explicit workspace save. The manual observation workflow below is a distinct supported entry for evidence-guided continuation, not a prerequisite for all image operations. Use only the methods needed for the question, with explicit budgets and stopping conditions.

Before acting, discover this connection's actual tool schemas, read its source/frame/calibration and current Panel/draft state, and recover relevant saved context. A tool's presence is not optional-dependency or scientific qualification. Return concise findings, alternative explanations and the smallest useful next observation to the researcher.

## Shared workspace, provenance and recovery

Working edits, explicit savepoints, immutable executions and display preferences are separate. Read the [workspace contract](docs/ANALYSIS_WORKSPACE.md) and [CLI contract](docs/CLI.md) before combining GUI and headless work. A saved A must not adopt an exploratory FFT(B) after Don't Save. Retain exact floating ROI association separately from integer processing support and never infer it from matching bounds alone.

For every write retain the original request ID before dispatch. Query the advertised original-outcome endpoint after timeout/cancellation; do not create a new ID to retry an unknown effect. A known existing/unqualified or unresolved FFT is not missing computation. Returning a saved view or reopening a helper is not permission to rerun science.

Use [owned Panel recovery](docs/INSPECTOR_PANEL_RECOVERY.md) only where its registration/checkpoint contract applies. A restored crystal card remains unvalidated until a new guarded evidence attachment checks current dependencies. Read current state separately from an old completed receipt.

When source proof is needed, inspect the advertised `image_source_proof`, `image_source_proof_info` and `image_source_proof_revoke` contracts. Recording a proof, adopting a reference and saving a workspace are separate actions. A retrospective proof preserves the FFT's original qualification; it cannot make unavailable pre-execution input evidence strictly reusable. Hash records are not digital signatures.

## Scientific routes

For HRTEM, use the [capability and evidence map](docs/HRTEM_BASELINE.zh-CN.md)
to connect the research question to the smallest useful existing route. The
[saved-band comparison](docs/hrtem-saved-band-task-a.md) describes ROI/reference
amplitude and wrapped phase from one eligible saved GPA. It is not raw-image
ingress or a reason to dispatch topology. Return usable per-band observations,
missing support and a next analysis suggestion separately from material claims.

To continue from two saved Panel regions into a finite structure comparison,
use the [manual ROI → crystal route](docs/MANUAL_CRYSTAL_WORKFLOW.md). Read its
additive `roi_handoff` for exact anchors/current calibration; share the two-window
atlas's FFT/measurement children across reviews and comparison. No full-field
scan or researcher-entered internal IDs is required. The
[integration record](docs/MANUAL_CRYSTAL_ACCEPTANCE.md) separates actual browser,
model and software evidence from physical qualification.

The formal F4b first-version path starts with a researcher-selected ROI and an
actual observation reason: explicitly use `image_discovery(entry="manual")`,
choose existing scientific tools, then bind/revise/recover their evidence with
`image_discovery_review`. A complete structure field is not required. Automatic
`entry="feature"` is **EXPERIMENTAL**; empty proposals never mean a normal image.
Its compatibility default is retained for old requests, not recommended for the
formal workflow. See [F4b scope](docs/IMAGE_FIRST_DISCOVERY.md).

For [active analysis](docs/ACTIVE_ANALYSIS.md), call `image_analysis_candidates`
on a saved domain map with explicit cumulative budgets. Select inspectable
actions through `image_field_extend`, rebuild `image_domain_map`, and evaluate
again. Keep reserved exploration and stop evidence visible. Save `active_plan`
beside the exact `spatial_field` and `domains` references. Query an incomplete
original extension before any further action; a new proposal never authorizes
replaying an unknown write. Committed observation-key measurement overrides can
revise a field without additional FFTs.

For [multiscale structural fields](docs/MULTISCALE_DOMAINS.md), use
`image_spatial_field` with explicit sizes, stride and a window budget, then
`image_domain_map` with a sourced reciprocal tolerance and explicit rotation
hypotheses. Review saved candidate supports/unknowns in the Panel. Save the exact
experiment, `spatial_field` and `domains` references in AnalysisContext; use
`previous_field_id` plus committed measurement overrides to revise observations
while preserving unchanged spectra. These tools provide candidate geometry,
not phase or defect confirmation.

Use this provider on Windows, macOS or Linux without DM/GMS or the old repository.
Start with [client setup](docs/CLIENT_SETUP.md). Discover the actual `image_*`,
optional `structure_*` and context tools from this connection. Missing optional
modules are not permission to call a peer DM provider or invent a capability.

For reusable Agent automation, load the [local MCP + Skills plugin](docs/AUTOMATION_PLUGIN.md).
Its `microscopy-automation` Skill uses formal bounded region/FFT/peak/measurement
tools and existing candidate comparisons, retaining current references by a named
AnalysisContext. No developer-session IDs or temporary scientific scripts are required.

For reconstructed sequences, use the [cross-frame tools](docs/SEQUENCE_PLUGIN.md):
save explicit frame order and sourced meaning, establish bounded ROI correspondence,
then compose existing FFT/peak/measurement operations into joint evidence. Recover
the named context and original requests after reconnecting; if no live Panel exists,
open the saved joint object with `image_panel_open` rather than rerunning science.

The [no-model inspector](docs/RESEARCHER_DATA_INSPECTOR.md) uses the same saved
arrays and measurement records. [Numerical inspection](docs/IMAGE_NUMERIC_INSPECTION.md)
reads original values, not preview brightness. Keep coordinates, signed XY
calibration, frame/ROI and FFT ancestry explicit; unknown scale stays pixel-based.
For direct `.dm3` / `.dm4`, use the [optional reader adapter](docs/DM4_DIRECT_IMPORT.md):
open the scientific catalog, then select frame0 and an explicit dataset when
ambiguous. Stored file calibration has source `dm_file_metadata`; it is neither
user confirmation nor DM-native execution. Never analyze the RGB thumbnail.
Save original request IDs before scientific writes and query original outcomes
after timeout. Preserve data and existing user/client settings.

For [ordinary complex 2D DM data](docs/DM_COMPLEX_IMAGES.md), choose an explicit
`image_preview.component` before opening its panel; numeric observations also
require their own explicit component. Preserve complex dtype and both parts in
NPY. Do not infer FFT/wave/phase semantics or feed a displayed amplitude into
an unqualified complex FFT/comparison. Packed and nD complex remain refused.

[Panel usage](docs/LOCAL_IMAGE_PANEL.md), [annotation contracts](docs/IMAGE_ANNOTATIONS.md)
and [reflection comparison](docs/REFLECTION_COMPARISON.md) describe the retained
scientific behavior. Older copied technical examples mentioning `DM_IMAGE_*`
refer to the pre-split combined checkout; for this package use the `MICROSCOPY_*`
configuration in client setup. Do not install GMS to satisfy those old examples.

Skills are optional user-installed directories. Copy a whole selected Skill
with its scripts and references, refusing overwrite. They do not establish that
an external Materials Project provider is connected. Do not install dependencies
or alter approval settings without explicit authorization.

DM is a separately registered peer MCP. Its native failures do not trigger a
hidden fallback. Imported saved captures are read-only scientific file transfer,
not a live host connection. New repository naming does not justify renaming old
request IDs, manifests, stored schemas or calibration records.

For a rank 3–6 DM source, inspect the catalog and call `image_frame` with explicit
`plane_axes:[Y,X]` in original NumPy axis order and one `plane_indices` entry
per axis (null on the two plane axes, fixed zero-based integers elsewhere).
The returned `dm_plane_selection` is scientific provenance, not a depth or
resolution inference. nD complex and packed DM inputs remain refused. Ordinary
2D complex inputs use the explicit component path above; never relabel them as
a produced external FFT or discard their imaginary values. See the reader
guide for scalar planes and the separately qualified complex scope.

R3 local evidence: `image_feature_field` saves a sparse, versioned local structure field (JSON/CSV/PNG) from an atlas, comparison or R2 observation without recomputing FFT; `image_spatial_atlas` composes existing ROI FFT/peak/measurement operations; `image_local_signature_compare` compares explicit in-plane rotation hypotheses using a saved atlas or R2 joint observations. See [SPATIAL_DOMAINS.md](docs/SPATIAL_DOMAINS.md). These are descriptive local reciprocal signatures, not automatic phase/twin/dislocation identification. TIFF admission now preserves finite grayscale float32 alongside uint16.
