# Bounded client receipt performance review

Current owning `tools/image_panel.mts` was independently transpiled under analysis; shared production/dist files were not changed. Profile uses actual compiled MCP/Python with a public 32×64 float32 cosine fixture, two 32×32 windows, one spatial field and two domain maps. No full spatial smoke, broad science or GUI. `probe.mjs` and `report.json` retain the trace.

## Confirmed regression

`acknowledgeDeliveredPreviews` rebuilds `refs`, `seen`, `records` and `done` on every write. Previously acknowledged immutable references are read and acknowledged again.

| Operation | Main RPC | Whole client call | Added reads/ACKs |
|---|---:|---:|---|
| two-window field | 449 ms | 1597 ms | 8 info + 3 ACK |
| first domain map | 532 ms | 1669 ms | same 8 info + same 3 ACK |
| second domain map | 437 ms | 1582 ms | same 8 info + same 3 ACK |

The repeated map follow-up RPCs reference identical object IDs and preview IDs; they add approximately 1.14 s per call on this machine (each extra worker RPC ~103–106 ms). A separate mocked counter with the same four immutable preview refs over three writes yields 12 info + 12 ACK, confirming behavior without scientific timing noise. A deterministic ACK request ID avoids new scientific objects but still launches the provider to recover the old receipt every time.

This demonstrates a material new client overhead. It does not establish that this overhead is the sole cause of CI's five-minute job timeout. Larger windows/fields, multiple map calls, platform import/startup cost and other tests in the job can compound it.

## Minimal fix recommendation

Keep two bounded, per-client caches: successfully acknowledged `(preview request ID, exact object ID)` pairs and immutable referenced object IDs whose complete reachable render-ref closure has been read and successfully acknowledged. Skip only those already-completed closures on later rendering writes. Scope caches to this workspace-bound receiving client; use bounded eviction (eviction merely repeats safe work). Read-only tool calls must return before touching receipt state.

Do not cache a closure if any info/JSON decode/ACK failed or budget was exceeded. Do not mark a parent's complete closure until all descendants succeed: otherwise the next call might skip an unresolved child. A successful individual ACK can be cached even if another branch fails, provided failed traversal remains retryable. Existing successful RPC error checks must remain, and first delivery of a new view still needs a durable ACK. Concurrency may at worst duplicate work unless a separate in-flight optimization is deliberately added.

This removes repeated map overhead but preserves initial receipt cost. A server-side batched operational receipt could reduce first-use cost but would be a wider contract change and is unnecessary for the minimal correction.

Suggested focused regression: two rendering replies share four immutable refs; second reply produces zero follow-up RPCs after successful first receipt; a new fifth ref is read/ACKed; failed info/ACK is retried; readonly evidence/info/result calls remain free of ACK side effects.

Command: `node analysis/sol70-performance/probe.mjs` — PASS. One initial development attempt used max_size128 and was rejected by existing minimum-size schema; corrected to256, no science was executed on that rejected attempt.

## Cache fix independent recheck

Reran the same two-window fixture against current owning client source, retaining `report-before-cache.json` and `report-after-cache.json` separately. Initial field remains 1596 ms (8 info + 3 ACK); map1 drops from1669 to441 ms and map2 from1582 to442 ms. Both map calls now have zero additional info/ACK RPCs, versus11 each previously. Mock repeated four-ref count drops from12 info/12 ACK to4/4. Production/dist were not edited by this reviewer.

Source inspection found no new admission authority or delivery inference: readonly methods return before cache creation; receipt cache requires exact successful original request/object receipt; complete closure is remembered only after traversal and ACK processing succeeds; failed info prevents closure publication and thrown ACK failure bypasses it. Cache capacity clears only local optimization state, so eviction can repeat safe reads/receipt recovery but cannot release durable admission. Cache is per workspace-bound client instance. No remaining blocker established for this minimal fix.

The probe's old mock initially returned an empty ACK body and was correctly rejected by the newly strengthened receipt validation. Updated only the analysis mock to return exact receipt fields before the successful real profile above. No full spatial smoke or GUI run.
