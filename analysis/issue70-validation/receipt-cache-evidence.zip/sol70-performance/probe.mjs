import ts from 'typescript';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
let output=ts.transpileModule(readFileSync('tools/image_panel.mts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
output=output.replace(/from\s*(['"])(\.[^'"]+)\1/g,(_m,_q,s)=>'from '+JSON.stringify(pathToFileURL(path.resolve('dist/tools',s)).href));
writeFileSync('analysis/sol70-performance/isolated.mjs',output);
const {StdioImageClient}=await import('./isolated.mjs');
const calls=[];const mock=Object.create(StdioImageClient.prototype),ids=[1,2,3,4].map(n=>n.toString(16).padStart(32,'0'));
mock.rpc=async(method,p)=>{calls.push(p.name);const object_id=p.arguments.object_id;const data=p.name==='image_info'?{object_id,preview_execution:{version:1,request_id:'original-'+object_id,object_id}}:{state:'completed',kind:'preview_acknowledgement',request_id:p.arguments.request_id,preview_request_id:p.arguments.preview_request_id,original_object_id:object_id,operational_receipt:true,scientific_object_created:false};return {result:{content:[{type:'text',text:JSON.stringify(data)}]}};};
for(let i=0;i<3;i++)await mock.acknowledgeDeliveredPreviews('image_domain_map',{samples:ids.map(view_object_id=>({view_object_id}))});
const mockResult={same_four_refs_three_writes:calls.reduce((a,n)=>(a[n]=(a[n]??0)+1,a),{})};
const python='/Volumes/External SSD/mircograph/fft-controlled-noise-20261102/.venv/bin/python';
const root=path.resolve('analysis/sol70-performance/actual-'+Date.now());mkdirSync(root);
const source=path.join(root,'public.tiff');const fixture=spawnSync(python,['-c',"import numpy as np,tifffile,sys;y,x=np.indices((32,64));tifffile.imwrite(sys.argv[1],(100+np.cos(2*np.pi*x/8)+np.cos(2*np.pi*y/8)).astype('float32'),metadata=None)",source],{encoding:'utf8'});if(fixture.status!==0)throw Error(fixture.stderr);
const client=new StdioImageClient({workspace:path.join(root,'workspace'),python,serverPath:path.resolve('dist/server.mjs')}),rpc=client.rpc.bind(client),trace=[];
client.rpc=async(method,p={})=>{const start=performance.now();try{return await rpc(method,p);}finally{if(method==='tools/call')trace.push({name:p.name,object_id:p.arguments.object_id,ms:performance.now()-start});}};
let serial=0;const invoke=async(name,args)=>{const before=trace.length,t=performance.now();const reply=await client.tool(name,{...args,request_id:'profile-'+(++serial)});return {data:reply.data,elapsed_ms:performance.now()-t,trace:trace.slice(before)};};
try{
 await client.rpc('initialize');const opened=await invoke('image_open',{source_path:source});const frame=await invoke('image_frame',{object_id:opened.data.object_id,frame_index:0});
 const field=await invoke('image_spatial_field',{object_id:frame.data.object_id,rect:[0,0,64,32],window_sizes:[32],stride_xy:[32,32],max_windows:2,coordinate_domain:'pixel',window:'none',subtract_mean:true,max_peaks:8,peak_options:{min_separation_bins:2,exclude_dc_radius_bins:2,threshold_rel:.18,refinement:'none'},max_size:256});
 const map1=await invoke('image_domain_map',{object_id:field.data.object_id,tolerance:.003,angles_degrees:[0,90],max_size:256});
 const map2=await invoke('image_domain_map',{object_id:field.data.object_id,tolerance:.004,angles_degrees:[0,90],max_size:256});
 const result={mockResult,root,scope:'current owning-source isolated transpilation; real compiled MCP/Python two-window fixture',field:{elapsed_ms:field.elapsed_ms,trace:field.trace},map1:{elapsed_ms:map1.elapsed_ms,trace:map1.trace},map2:{elapsed_ms:map2.elapsed_ms,trace:map2.trace}};
 writeFileSync('analysis/sol70-performance/report.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{await client.close();}
