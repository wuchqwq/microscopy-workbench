import sys,json,uuid
from pathlib import Path
import numpy as np,tifffile
sys.path.insert(0,str(Path.cwd()/'tools'));import image_workspace as w
root=Path.cwd()/'analysis/independent70'/('missing-claim-'+uuid.uuid4().hex);root.mkdir();ws=root/'workspace';source=root/'public.tiff';tifffile.imwrite(source,np.arange(1024,dtype='float32').reshape(32,32))
def call(action,ident,**args):return w.execute(dict(workspace=str(ws),action=action,request_id=ident,**args))
a=call('open','source',source_path=str(source))['result'];f=call('frame','frame',object_id=a['object_id'],frame_index=0)['result'];v=call('view','original',object_id=f['object_id'])['result']
claim=next((ws/'preview-admission-v1/resources').glob('*.json'));(root/'removed-claim.json').write_bytes(claim.read_bytes());claim.unlink()
new=call('view','replacement',object_id=f['object_id'],max_size=64)
result={'injection':'one resource claim lost; original intent/journal preserved; no acknowledgement sent','original':v['object_id'],'new_ok':new['ok'],'new_object':new.get('result',{}).get('object_id'),'new_error':new.get('error'),'original_journal_exists':(ws/'requests/original.json').exists(),'original_intent_exists':(ws/'preview-admission-v1/intents/original.json').exists()};(root/'report.json').write_text(json.dumps(result,indent=2));print(json.dumps({'root':str(root),**result},indent=2))
