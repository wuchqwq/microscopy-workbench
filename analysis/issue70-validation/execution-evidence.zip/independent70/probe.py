import sys,json,uuid
from pathlib import Path
import numpy as np,tifffile
sys.path.insert(0,str(Path.cwd()/'tools'))
import image_workspace as w
root=Path.cwd()/'analysis'/'independent70'/uuid.uuid4().hex;root.mkdir()
source=root/'public.tiff';tifffile.imwrite(source,np.arange(4096,dtype='float32').reshape(64,64))
ws=root/'workspace';n=0

def call(action,**kwargs):
 global n
 n+=1
 return w.execute(dict(workspace=str(ws),action=action,request_id='probe-'+str(n),**kwargs))
def ok(action,**kwargs):
 r=call(action,**kwargs);assert r['ok'],r
 return r['result']
a=ok('open',source_path=str(source));f=ok('frame',object_id=a['object_id'],frame_index=0)
reserved=call('view',object_id=f['object_id'],_preview_phase='reserve');assert reserved['ok'],reserved
original=reserved['preview_admission']['request_id']; before=len(list((ws/'objects').glob('*/object.json')))
d=call('discovery',object_id=f['object_id'],entry='manual',selection_origin='agent',regions=[{'rect':[0,0,32,32],'reason':'Independent controlled review fixture'}],max_size=64)
after=len(list((ws/'objects').glob('*/object.json')))
views=[json.loads(p.read_text())['request_id'] for p in (ws/'objects').glob('*/object.json') if json.loads(p.read_text())['kind']=='view']
result={'original_request':original,'original_state':w.execute(dict(workspace=str(ws),action='result',query_request_id=original)),'discovery_ok':d['ok'],'discovery_error':d.get('error'),'objects_before':before,'objects_after':after,'new_view_requests':views}
# Controlled sidecar corruption: existing dispatched fence must disprove not_submitted.
intent=ws/'preview-admission-v1'/'intents'/(original+'.json')
fence=intent.with_suffix('.dispatch');fence.write_text(json.dumps({'version':1,'request_id':original,'state':'dispatched'}))
intent.write_text(json.dumps({'version':1,'state':'not_submitted'}))
new=call('view',object_id=f['object_id'],max_size=64)
result['malformed_intent_with_dispatched_fence']={'ok':new['ok'],'error':new.get('error'),'new_object':new.get('result',{}).get('object_id')}
(root/'report.json').write_text(json.dumps(result,indent=2));print(json.dumps({'root':str(root),**result},indent=2))
