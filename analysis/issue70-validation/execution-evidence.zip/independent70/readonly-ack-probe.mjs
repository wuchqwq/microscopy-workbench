import {StdioImageClient} from '../../dist/tools/image_panel.mjs';
import {writeFileSync} from 'node:fs';
const id='a'.repeat(32),calls=[];
const c=Object.create(StdioImageClient.prototype);
c.rpc=async(method,p)=>{calls.push(p.name);const data=p.name==='image_evidence'?{kind:'spatial_atlas',overview_object_id:id}:p.name==='image_info'?{object_id:id,preview_execution:{version:1,request_id:'original-preview',object_id:id}}:{kind:'preview_acknowledgement'};return {result:{content:[{type:'text',text:JSON.stringify(data)}]}};};
await c.tool('image_evidence',{object_id:'b'.repeat(32),section:'summary'});
writeFileSync('analysis/independent70/readonly-ack-result.json',JSON.stringify({calls},null,2));console.log(JSON.stringify(calls));
