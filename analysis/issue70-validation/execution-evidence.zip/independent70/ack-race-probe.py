import sys,json,uuid
from pathlib import Path
from unittest.mock import patch
import numpy as np,tifffile
sys.path.insert(0,str(Path.cwd()/'tools'))
import image_workspace as w
root=Path.cwd()/'analysis'/'independent70'/('ack-'+uuid.uuid4().hex);root.mkdir();ws=root/'workspace'
source=root/'public.tiff';tifffile.imwrite(source,np.arange(1024,dtype='float32').reshape(32,32))
def call(action,ident,**args): return w.execute(dict(workspace=str(ws),action=action,request_id=ident,**args))
a=call('open','open',source_path=str(source))['result'];f=call('frame','frame',object_id=a['object_id'],frame_index=0)['result'];v=call('view','preview',object_id=f['object_id'])['result']
write=w.preview_admission._write;observed={}
def interleave(path,value,api,exclusive=False):
 if path.parent.name=='acknowledged':
  # Other process runs after ACK checked namespace, before ACK publishes receipt.
  observed['science']=call('context','shared-request',object_id=f['object_id'],metadata={'source_text':'controlled independent review'})
 return write(path,value,api,exclusive)
with patch.object(w.preview_admission,'_write',interleave):
 observed['ack']=call('preview_acknowledge','shared-request',preview_request_id='preview',object_id=v['object_id'])
observed['recovery']=w.execute(dict(workspace=str(ws),action='result',query_request_id='shared-request'))
observed['both_files_exist']=(ws/'requests/shared-request.json').exists() and (ws/'preview-admission-v1/ack-requests/shared-request.json').exists()
(root/'report.json').write_text(json.dumps(observed,indent=2));print(json.dumps({'root':str(root),'science_ok':observed['science']['ok'],'ack_ok':observed['ack']['ok'],'recovered_kind':observed['recovery'].get('result',{}).get('kind'),'both_files_exist':observed['both_files_exist']},indent=2))
