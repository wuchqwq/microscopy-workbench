import sys,os,json,importlib.util
from pathlib import Path
p=Path(sys.argv[-1]);sys.path.insert(0,str(p.parent))
spec=importlib.util.spec_from_file_location('image_workspace',p);m=importlib.util.module_from_spec(spec);sys.modules['image_workspace']=m;spec.loader.exec_module(m)
original=m.Workspace.action
def interrupted(self,action,*args):
 if action=='view':os._exit(73)
 return original(self,action,*args)
m.Workspace.action=interrupted
reply=m.execute(json.loads(sys.stdin.buffer.read()));print(json.dumps(reply))
