# Independent #70 review — initial implementation

Read AGENTS.md and the approved Route B design at `recovery-handoff-design-20261102/docs/proposals/ISSUES_70_72_RECOVERY_HANDOFF_DESIGN.md`. Reviewed only #70, not #72. No production edits, no browser/model operations, no future blind-test materials. Ran one small independent Python provider probe rather than any full suite.

## Blocking findings

### P1 — official composition children bypass durable preview admission

Location: `tools/image_workspace.py:2077–2108` places admission only in public `execute`; `tools/image_automation.py:26–34` calls `module._execute` directly. `tools/image_discovery.py:161` and context-region helpers create `view` children through that path.

Trigger: reserve a preview for a frame and leave its original journal missing/intent reserved. Call manual `discovery` on the same frame with a different parent request. The original remains `unknown`, but discovery successfully creates a fresh context `view` and associated objects. This is an existing advertised entry, not a private method called by the probe.

Observed: object count 2 → 5; new view child `auto-29ca64fc346360fb697f0c673974a96dffca743e545ad520`; original `probe-3` still `INCOMPLETE_PREVIEW_INTENT`, `automatic_retry:false`. Therefore protection is not shared by all provider preview writes and the Route B across-entry contract is not met. Moving admission to the common owning write boundary must preserve the exact return contract expected by internal composition children. Legitimate sequential children need explicit receipts actually consumed by that parent; disk completion alone must not create implicit acknowledgment.

### P1 — malformed prior intent can assert not_submitted despite a dispatched fence

Location: `tools/preview_admission.py:30–36,130–147` validates only version on read, then accepts `old_intent.state == 'not_submitted'` without validating its identity, parameter/resource binding, or matching one-use abort fence. `outcome:184–195` also trusts that state independently.

Controlled corruption: replace the prior intent with valid JSON `{"version":1,"state":"not_submitted"}` while a same-ID fence says `dispatched`. New same-source preview succeeds. The test deliberately injects contradictory sidecar data; it does not claim an actual power-loss incident produced those bytes. Nonetheless the stated corrupt-sidecar fail-closed contract and requirement that only an abort fence proves non-dispatch are violated. The missing original journal remains insufficient to prove non-execution.

Require strict identity/resource/parameter and state/fence consistency before unlocking or reporting not_submitted. Missing, malformed or inconsistent evidence must remain protected/unknown. Scientific journals and old result bytes must remain unchanged.

## Independent evidence

- Script: `analysis/independent70/probe.py`.
- Result and retained workspace: `analysis/independent70/c0b4f6a0a40649b3ba3d8322fd52dc97/report.json`.
- Command: `'/Volumes/External SSD/mircograph/fft-controlled-noise-20261102/.venv/bin/python' analysis/independent70/probe.py`.
- Real independent Python provider, public synthetic 64×64 TIFF; no browser/MCP transport claim for this probe.
- Result: both counterexamples reproduced. No full suite run.

Root acknowledged both findings and requested probe pause while implementing fixes. This initial report is not approval of the revised tree. Post-fix read-only verification remains pending.

## Follow-up review after common-boundary / ACK changes

The original two counterexamples are now blocked. Reran the exact original probe into a new independent directory: `analysis/independent70/85b1d03705b04b2c9c896a12ba594b8c/report.json`. Discovery refuses the unknown parent preview, object count stays 2, no view is created; malformed prior intent returns PREVIEW_ADMISSION_CORRUPT. Original failing artifacts remain unchanged.

### New P1 — ACK request identity is not atomically exclusive with scientific requests

Location: `tools/preview_admission.py:224–250` checks competing paths, publishes the acknowledged marker, and only then exclusively creates the ACK request receipt. `tools/image_workspace.py:1971` likewise checks ACK-path absence separately from creating its scientific journal. These are different files with no shared atomic request-ID reservation.

Deterministic interleave: pause ACK after its namespace checks, before writing the marker; run an ordinary `context` request with that same ID; resume ACK. Both return ok:true. Both scientific journal and ACK receipt exist for `shared-request`, but image_result recovers only the context object, so the ACK no longer has unambiguous original-request recovery. This is a modeled legal two-process scheduling interleave, executed against actual provider code; not an OS scheduler stress test.

Evidence: `analysis/independent70/ack-race-probe.py`, retained result `analysis/independent70/ack-f2c96fddfd454341ad9f041ef483b4e2/report.json`. Reserve request identity atomically in a common namespace before publishing the marker. The same ordering also permits a losing concurrent conflicting ACK to publish its marker before returning REQUEST_CONFLICT, or a crash to publish a marker without any recoverable ACK request record.

### New P2 — receiving client auto-acknowledges read-only evidence queries

Location: `tools/image_panel.mts:61–77`. The helper excludes only image_info, image_result, and image_preview_acknowledge. `image_evidence` is another read-only tool; its returned overview/view references are therefore followed and acknowledged. This violates the stated write-results-only client policy and turns a read-only bounded evidence query into durable admission release.

Owning-source isolated transpilation plus mock RPC observed calls `image_evidence → image_info → image_preview_acknowledge`. Evidence: `analysis/independent70/source-readonly-ack-probe.mjs` and `source-readonly-ack-result.json`. Shared dist was stale, so it was not rebuilt or overwritten; the isolated module lives only under analysis. This is a client-method boundary probe, not formal MCP/browser evidence. Prefer positive classification of allowed write results rather than an incomplete read-tool denylist.

### Delivery boundary assessment

The new automatic ACK is initiated by the receiving StdioImageClient only after its complete successful RPC result has decoded, not by the server merely because its scientific journal completed. That is a defensible first-party-client receipt boundary. It does not prove an Agent or human saw the result or that Panel HTTP presentation completed, and reporting should retain that precise limit. Read-only recovery exclusion and atomic request-ID ownership still need the fixes above before approval.

## Final requested recheck — original findings resolved; missing-claim case remains

Replayed only independent counterexamples, not broader suites:

- ACK ID interleave now rejects the competing science request; ACK succeeds, and image_result recovers `preview_acknowledgement`. Evidence: `analysis/independent70/ack-45c7b6fc7182414aa445895e8687c13e/report.json`.
- Owning-source client probe now calls only `image_evidence`; no image_info or ACK side effect. Evidence: `source-readonly-ack-result.json`; the preceding failure result was copied to `source-readonly-ack-result-before-final-fix.json` before rerun.
- Original unknown/composition and malformed-intent probes remain blocked, with no new views. Evidence: `analysis/independent70/3bd54fd7c0734bbb9c496558c3becea6/report.json`.

### Remaining P1 under the promised corrupt-sidecar fail-closed scope — missing resource claim is treated as first use

Location: `tools/preview_admission.py:159–184`. The existence of `resources/<resource>.json` alone decides whether prior owner resolution is required. A missing claim skips all prior-intent/journal checks, although those durable records still exist.

Minimal controlled case: complete one preview, send no ACK; remove only its resource claim file, preserving its original intent, journal and object; submit same frame with a new ID/max_size. The new request succeeds and creates another view. This violates the stated no-delivery/corrupt-sidecar fail-closed contract. It is a deliberately injected single-sidecar loss, not a claim that normal successful fsync causes spontaneous deletion, and not deletion of the whole operational database.

Evidence: `analysis/independent70/missing-claim-probe.py`; retained result `analysis/independent70/missing-claim-6f198d41e3be46b08080c48327bce089/report.json`; removed claim bytes retained as `removed-claim.json`. Original view `55c5cc5a1794434f91999e7ee5abf53e`, replacement `bbec232357c64e3b8fed93ffd2e64c36`, both original intent and journal still present.

Either detect this incomplete resource-index state before first-use admission and fail closed, or explicitly narrow the supported corruption guarantee. The reviewed implementation otherwise resolves the prior four findings. No production code or shared build outputs were changed.
