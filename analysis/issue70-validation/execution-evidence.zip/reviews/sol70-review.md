# Independent Sol review of revised #70

Read `AGENTS.md`, the #70/#72 recovery design, and `analysis/independent70-review.md`. Reviewed the provider admission/dispatch, composition children, and receiving Panel client sources. No production or shared build edits; no GUI, model, MCP transport, or broad science suite. Review scope is the current working tree, not a historical commit.

## Blocking finding

### P2 — losing a request-ID race permanently poisons a previously unused preview resource

Location: `tools/preview_admission.py:159–167,193–210`.

`prepare` publishes the first-use immutable anchor before acquiring the common request-ID reservation. A competing ordinary science request can legally win that request ID after `_execute` checked journal absence but before `prepare` reserves it. Preview correctly returns `REQUEST_CONFLICT`; however, its new anchor remains without a resource claim. Every subsequent preview of the same input, including a fresh request ID, returns `PREVIEW_ADMISSION_CORRUPT`. No preview was ever dispatched, and querying the losing ID only recovers the competing context; there is no original preview outcome to acknowledge. This creates permanent resource unavailability from an otherwise correctly rejected concurrent ID conflict.

Independent deterministic legal interleave against actual provider code: hook `_write` at first anchor publication, invoke a real `context` request with the same ID, then resume preview. Observed context success, losing preview `REQUEST_CONFLICT`, fresh-ID preview `PREVIEW_ADMISSION_CORRUPT`, and zero view objects. This is a scheduling probe, not an OS scheduler stress test or injected disk corruption.

Evidence: `analysis/sol70/anchor-race-probe.py`; retained report `analysis/sol70/anchor-race-183a21e4643041259442c691834b6614/report.json`.

Acquire the original request namespace before publishing first-use resource metadata (or explicitly roll back only this provably unclaimed, undispatched first-use anchor on request-conflict). Do not relax missing-claim protection for real prior owners or use elapsed time/PID to infer non-execution. A focused collision regression should verify the losing resource remains usable with a fresh ID and the winning original journal is unchanged.

## Prior findings

- Central `_execute` now gates composition `view` children; `run_child` uses the current top-level ContextVar receipt map. The original direct `_execute` bypass is closed by source inspection.
- `_intent` validates complete identity/binding and not-submitted fence plus journal consistency; the prior partial-JSON not-submitted assertion is closed by source inspection.
- ACK requests reserve the same authoritative `requests` namespace before marker publication. The prior separate-namespace race is closed by source inspection.
- The receiving client positively classifies rendering writes; `image_evidence`, `image_info`, and `image_result` do not auto-ACK. The prior read-only ACK side effect is closed by source inspection.
- Replayed the original missing-single-claim probe: new preview now fails `PREVIEW_ADMISSION_CORRUPT`; original intent and journal survive. Evidence: `analysis/independent70/missing-claim-8b060db21c4a4ae3b025846c9e384dd9/report.json`. The immutable anchor closes that exact counterexample, but introduces the ordering issue above.

No additional write bypass or incorrect unlock was established in this review. Deleting both resource anchor and claim, or whole operational directories, is outside the demonstrated single-sidecar-loss guarantee. Client receipt still means successful decoding by the first-party client, not proof an Agent/human saw a view.

## Commands and limits

- PASS (counterexample reproduced): `'/Volumes/External SSD/mircograph/fft-controlled-noise-20261102/.venv/bin/python' analysis/sol70/anchor-race-probe.py`.
- PASS (old hole blocked): same Python, `analysis/sol70/missing-claim-recheck.py` (copy of the original independent probe).
- NOT_TESTED: broad suites, GUI, formal MCP transport, real-user receipt, and #72.

Approval remains blocked on the first-use-anchor/request-reservation ordering issue. Existing passing suites do not exercise this legal interleave.

## Post-fix recheck

Root moved first-use anchor publication after successful exclusive acquisition of the common request namespace, still under the resource lock. Added only one focused regression in `tests/test_preview_admission.py`: `test_losing_global_request_id_race_does_not_poison_unused_preview_resource`. Its deterministic hook dispatches the competing real context immediately before the preview-reserved request write; it verifies the winner's exact journal bytes survive, no resource metadata is stranded, and a fresh preview succeeds. This test passes (1 test, 0.017 s). No production edits by this reviewer.

Updated the independent probe scheduling hook to the same pre-reservation boundary; the original failure artifact above remains unchanged. The ordering defect is resolved. No remaining blocking finding established within this review's scope; broad/GUI/formal MCP scopes remain NOT_TESTED here.
