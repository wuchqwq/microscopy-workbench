import sys, uuid, json
from pathlib import Path
from unittest.mock import patch
import numpy as np
import tifffile
sys.path.insert(0, str(Path.cwd()/'tools'))
import image_workspace as w
root=Path.cwd()/'analysis/sol70'/('anchor-race-'+uuid.uuid4().hex)
root.mkdir(); source=root/'public.tiff'; ws=root/'workspace'
tifffile.imwrite(source,np.arange(1024,dtype='float32').reshape(32,32))
def call(action,ident,**kw):
    return w.execute(dict(action=action,workspace=str(ws),request_id=ident,**kw))
opened=call('open','source',source_path=str(source))['result']
frame=call('frame','frame',object_id=opened['object_id'],frame_index=0)['result']
original=w.preview_admission._write
interleaved=[]
def hook(path,value,api,exclusive=False):
    if path.parent.name=='requests' and value.get('state')=='preview_reserved' and not interleaved:
        interleaved.append(call('context','race',object_id=frame['object_id'],metadata={'source_text':'competing request'}))
    return original(path,value,api,exclusive)
with patch.object(w.preview_admission,'_write',hook):
    preview=call('view','race',object_id=frame['object_id'])
fresh=call('view','fresh',object_id=frame['object_id'])
report={'competing_context_ok':interleaved[0]['ok'],'preview':preview,'fresh':fresh,
        'resource_files':[p.name for p in (ws/'preview-admission-v1/resources').iterdir()],
        'view_count':sum(json.loads(p.read_text()).get('kind')=='view' for p in (ws/'objects').glob('*/object.json'))}
(root/'report.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'root':str(root),**report},indent=2))
